#!/bin/bash.
pepcoil -sequence ./seq3.fa -window 28 -coil -frame -noother -rformat motif -auto -outfile outbash1.pepcoil > /dev/null
python software5.py