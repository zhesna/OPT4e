
# coding: utf-8

# In[ ]:


import numpy as np
import pandas as pd
import os
import sys
import subprocess
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import scale
import shutil
from shutil import copyfile
import tkinter
from tkinter import *
from IPython.display import display
from IPython.display import HTML
import IPython.core.display as di 

